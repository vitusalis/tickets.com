<template>
    <div class="about">
        <div class="page-title">
            <h1>Sobre nós</h1>
        </div>

        <div class="section">
            <p class="section-text">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque
                nulla necessitatibus deleniti itaque, quae in rerum ut
                voluptatem ex recusandae harum hic quos odio? Consectetur
                quisquam sunt, fugiat eum officiis minima corrupti.
            </p>
            <p class="section-text">
                Consequatur dolore provident ducimus ex, accusantium quae quam
                porro adipisci et. Quos ad maxime, perspiciatis suscipit soluta
                consequatur cupiditate! Cumque, laboriosam sint? Dolorem
                veritatis dicta necessitatibus doloribus quidem.
            </p>
        </div>
    </div>
</template>
